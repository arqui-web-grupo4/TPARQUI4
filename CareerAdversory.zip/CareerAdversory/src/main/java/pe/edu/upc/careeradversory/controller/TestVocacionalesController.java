package pe.edu.upc.careeradversory.controller;

public class TestVocacionalesController {
}
