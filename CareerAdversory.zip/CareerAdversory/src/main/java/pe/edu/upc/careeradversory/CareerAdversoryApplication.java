package pe.edu.upc.careeradversory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerAdversoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(CareerAdversoryApplication.class, args);
    }

}
