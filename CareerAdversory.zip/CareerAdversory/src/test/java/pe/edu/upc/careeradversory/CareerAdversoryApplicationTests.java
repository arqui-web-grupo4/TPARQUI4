package pe.edu.upc.careeradversory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CareerAdversoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
